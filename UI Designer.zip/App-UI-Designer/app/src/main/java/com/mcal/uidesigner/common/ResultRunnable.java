package com.mcal.uidesigner.common;

public interface ResultRunnable<T> {
    T run();
}
