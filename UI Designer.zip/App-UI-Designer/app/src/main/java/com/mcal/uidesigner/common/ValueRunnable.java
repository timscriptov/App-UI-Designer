package com.mcal.uidesigner.common;

public interface ValueRunnable<T> {
    void run(T t);
}
